from flask import Flask, render_template, jsonify, redirect, url_for, request
from data import DataAccess as da
import json

app = Flask(__name__)

@app.route("/")
def index():
    da.connexion()
    etudiants = da.get_etudiants()
    da.deconnexion()

    return render_template("index.html", etudiants=etudiants)

if __name__ == "__main__" :
    app.run(debug=True)