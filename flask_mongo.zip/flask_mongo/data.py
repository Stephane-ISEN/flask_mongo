from pymongo import MongoClient

class DataAccess :
    user = "root"
    mdp = "pass12345"
    serveur = "127.0.0.1"
    port = "27018"
    db_name = "ecole"
    collection_name = "etudiants"

    # méthode de classe
    @classmethod
    def connexion(cls) :
        #connexion à la base mongo
        cls.client = MongoClient(f"mongodb://{cls.user}:{cls.mdp}@{cls.serveur}:{cls.port}")

        # variable de classe qui représente la BDD
        cls.db = cls.client[cls.db_name]
        # variable de classe qui représente la collection
        cls.etudiants = cls.db[cls.collection_name]

    # méthode de classe
    @classmethod
    def deconnexion(cls) :
        #il suffit de fermer le client
        cls.client.close()

