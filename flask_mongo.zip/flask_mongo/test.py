from data import DataAccess as da

# méthodes de classe, pas besoin de créer d'objet
da.connexion()

da.deconnexion()
# s'il n'y a pas de message d'erreur dans la console c'est que la connexion est ok

